package com.jeon.mvvm_kakao_image.datas



data class KakaoData (val documents:List<ImageData>)

data class ImageData(val image_url:String)
